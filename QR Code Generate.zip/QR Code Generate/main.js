function generateQR(){
    let IF1 = document.getElementById('InputFiled1').value;
    let IF2 = document.getElementById('InputFiled2').value;
    let IF3 = document.getElementById('InputFiled3').value;
    let IF4 = document.getElementById('InputFiled4').value;
    let qrdiv = document.getElementById('qrcode');

    let allFiled = IF1 +" "+ IF2 + "\n\n" + IF3 + " " + IF4;

    if(allFiled){
        qrdiv.innerHTML = "";
        new QRCode(qrdiv,allFiled);
        document.getElementById('qr-container').style.display = "block";
    }else{
        alert("Input Is Null");
    }
}